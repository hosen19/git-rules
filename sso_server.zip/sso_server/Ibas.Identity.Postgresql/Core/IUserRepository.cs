﻿using Ibas.Identity.Postgresql.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Core
{
    public interface IUserRepository<Tuser> : IGeneric<Tuser> where Tuser : class
    {
        /// <summary>
        /// Find and Return a users from store
        /// </summary>
        /// <param name="userName">The user's login id</param>
        /// <returns></returns>
        Task<Tuser?> FindByNameAsync(string userName, CancellationToken cancellationToken);
        /// <summary>
        /// Find and return a user from store
        /// </summary>
        /// <param name="email">The user's email</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<Tuser?> FindByEmailAsync(string email, CancellationToken cancellationToken);
    }
}
