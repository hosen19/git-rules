﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Core
{
    public interface ICustomIdentityDbContext<Tuser> where Tuser : class
    {
        IUserRepository<Tuser> UserRepository { get; }
    }
}
