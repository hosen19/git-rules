﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Core
{
    public interface IPostgreDbUtil
    {
        Task<int> ExecuteSQLAsync(string commandText, Dictionary<string, object> parameters);
        object ExecuteQueryGetSingleObject(string commandText, Dictionary<string, object> parameters);
        Dictionary<string, string> ExecuteQueryGetSingleRow(string commandText, Dictionary<string, object> parameters);
        List<Dictionary<string, string>> ExecuteQuery(string commandText, Dictionary<string, object> parameters);
        void OpenConnection();
        void CloseConnection();
        Task<object> InsertAsync(DbConnection connection, DbTransaction transaction, string sql, Dictionary<string, object> parameters);

        DbConnection MakeConnection();
        DbTransaction BeginTransaction(DbConnection connection);
        void CommitTransaction(DbTransaction Transaction);
        void RollBackTransaction(DbTransaction Transaction);

    }
}
