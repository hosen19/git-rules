﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Core
{
    public interface IGeneric<T>
        where T : class
    {
        Task InsertOrUpdateAsync(T entity, CancellationToken cancellationToken);
        Task SaveAsync(T entity, CancellationToken cancellationToken);
        Task DeleteAsync(T entity, CancellationToken cancellationToken);
        Task<T> FindAsync<Tkey>(Tkey? id, CancellationToken cancellationToken);
        Task<List<T>> GetAllAsync();
        Task<T> GetByIdAsync(string id, CancellationToken cancellationToken);


    }
}
