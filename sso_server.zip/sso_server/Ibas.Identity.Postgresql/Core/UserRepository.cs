﻿using Ibas.Identity.Postgresql.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Core
{
    /// <summary>
    /// User information repository to get the user information from postgresql db
    /// </summary>
    /// <typeparam name="Tuser"></typeparam>
    public class UserRepository<Tuser> : IUserRepository<Tuser> where Tuser : IdentityUser<long>, new()
    {
        /// <summary>
        /// PostgreSQL Utility
        /// </summary>
        private readonly IPostgreDbUtil postgreDbUtil;

        public UserRepository(IPostgreDbUtil dbUtil) {
            this.postgreDbUtil = dbUtil;
        }

        #region User Implementation

        /// <summary>
        /// Delete User information from user acount table
        /// </summary>
        /// <param name="entity">The User whose are stored in database</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task DeleteAsync(Tuser entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  Return a user with the matching userId if it exists.
        /// </summary>
        /// <typeparam name="Tkey"></typeparam>
        /// <param name="id">The user's id.</param>
        /// <param name="cancellationToken"> used to propagate notifications that the operation should be canceled.</param>
        /// <returns>The user if it exists.</returns>
        public async Task<Tuser> FindAsync<Tkey>(Tkey? id, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            ArgumentNullException.ThrowIfNull(id);
            var userId = Convert.ToString(id);
            return await GetByIdAsync(userId, cancellationToken);
        }

        /// <summary>
        ///  Return a user with the matching userId if it exists.
        /// </summary>
        /// <param name="userName">The user's login id.</param>
        /// <returns>The user if it exists.</returns>
        public async Task<Tuser?> FindByNameAsync(string userName, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Tuser user = null;

            await Task.Run(() =>
            {
                user = GetUserByUserName(userName);
            });
            return user;
        }

        /// <summary>
        /// Return a user with the matching userId if it exists.
        /// </summary>
        /// <param name="email">The user's email.</param>
        /// <param name="cancellationToken">used to propagate notifications that the operation should be canceled.</param>
        /// <returns>The user if it exists.</returns>
        public async Task<Tuser?> FindByEmailAsync(string email, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            ArgumentNullException.ThrowIfNull(email);
            return await GetByEmailAsync(email);
        }

        public async Task< List<Tuser>> GetAllAsync()
        {
            return new List<Tuser>();
        }

        /// <summary>
        /// Return a user with the matching userId if it exists.
        /// </summary>
        /// <param name="id">The user's id.</param>
        /// <returns>The user if it exists.</returns>
        public async Task<Tuser> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Tuser user = null;
            var userId = Convert.ToInt64(id);
            await Task.Run(() =>
            {
                user = GetUserByUserId(userId);
            });
            return user;
        }

        /// <summary>
        /// Get User information by email id if exits
        /// </summary>
        /// <param name="email">The user's email id</param>
        /// <returns>The user if it exists.</returns>
        private async Task<Tuser> GetByEmailAsync(string email)
        {
            Tuser user = null;

            await Task.Run(() =>
            {
                user = GetUserByEmail(email);
            });
            return user;
        }

        
        /// <summary>
        /// Update User information if exists
        /// </summary>
        /// <param name="entity">The user to update</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>

        public async Task InsertOrUpdateAsync(Tuser entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            ArgumentNullException.ThrowIfNull(entity);
            AppUser user = entity as AppUser;

            string userPasswordSql = "update s_user_password set password_text = @password_text, password_start_date = @password_start_date, password_end_date = @password_end_date where user_account_id = @user_account_id  ";

            Dictionary<string, object> userPasswordParams = new Dictionary<string, object>();
            userPasswordParams.Add("@user_account_id", user.Id);
            userPasswordParams.Add("@password_text", user.PasswordHash);
            userPasswordParams.Add("@password_start_date", user.PasswordStartDate);
            userPasswordParams.Add("@password_end_date", user.PasswordEndDate);

            try
            {
                var id = postgreDbUtil.ExecuteSQLAsync(userPasswordSql, userPasswordParams);
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }

        }

        /// <summary>
        /// Saves the user in PostgreSql store.
        /// </summary>
        /// <param name="appUser">The user to create</param>
        /// <returns>The <see cref="Task"/> that represents the asynchronous operation.</returns>
        public async Task SaveAsync(Tuser appUser, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            ArgumentNullException.ThrowIfNull(appUser);
            AppUser user = appUser as AppUser;

            using (DbConnection dbConnection = postgreDbUtil.MakeConnection())
            {
                await dbConnection.OpenAsync();
                DbTransaction transaction = postgreDbUtil.BeginTransaction(dbConnection);

                try
                {

                    var lowerCaseEmail = user.Email == null ? null : user.Email.ToLower();
                    // user_account_id, @id, 
                    string commandText = "insert into s_user_account " +
                        "(user_login_id,logon_flag,locked_flag,login_attempts,user_account_name_en,user_account_name_bn,gender_type_id,dob,email,mobile_no,nid_no,smart_no,reference_status_id,create_date,version_no,security_stamp,remarks)" +
                        " VALUES ( @user_login_id, @logon_flag, @locked_flag, @login_attempts, @user_account_name_en, @user_account_name_bn, @gender_type_id,@dob, @email, @mobile_no, @nid_no, @smart_no, @reference_status_id, @create_date, @version_no, @security_stamp, @remarks  ) RETURNING user_account_id ; ";
                    
                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    //parameters.Add("@id", user.Id);
                    parameters.Add("@user_login_id", user.UserName);
                    parameters.Add("@logon_flag", user.LogonFlag == null ? "Y" : user.LogonFlag);
                    parameters.Add("@locked_flag", user.LockoutEnabled == true ? 'Y' : 'N');
                    parameters.Add("@login_attempts", user.AccessFailedCount);
                    parameters.Add("@user_account_name_en", user.UserAccountNameEn);
                    parameters.Add("@user_account_name_bn", user.UserAccountNameBn);

                    parameters.Add("@gender_type_id", user.GenderTypeId);
                    parameters.Add("@dob", user.Dob);
                    parameters.Add("@email", user.Email);
                    parameters.Add("@mobile_no", user.PhoneNumber);
                    parameters.Add("@nid_no", user.NidNo);
                    parameters.Add("@smart_no", user.SmartNo);
                    parameters.Add("@reference_status_id", user.ReferenceStatusId);
                    parameters.Add("@create_date", user.CreateDate);
                    parameters.Add("@version_no", user.VersionNo);
                    parameters.Add("@security_stamp", user.SecurityStamp);
                    parameters.Add("@remarks", user.Remarks);

                    var userAccountId = await postgreDbUtil.InsertAsync(dbConnection, transaction, commandText, parameters);

                    user.Id = Convert.ToInt64(userAccountId);

             
                    string userPasswordSql = "insert into s_user_password " +
                        " (user_account_id,password_text,password_start_date,password_end_date,reference_status_id,create_date,version_no) " +
                        " values (@user_account_id,@password_text, @password_start_date, @password_end_date,@reference_status_id,@create_date,@version_no) RETURNING user_password_id; ";


                    Dictionary<string, object> userPasswordParams = new Dictionary<string, object>();
                   // userPasswordParams.Add("@user_password_id", Convert.ToInt64( user.Id));
                    userPasswordParams.Add("@user_account_id", user.Id);
                    userPasswordParams.Add("@password_text", user.PasswordHash);
                    userPasswordParams.Add("@password_start_date", user.PasswordStartDate);
                    userPasswordParams.Add("@password_end_date", user.PasswordEndDate);
                    userPasswordParams.Add("@reference_status_id", user.ReferenceStatusId);
                    userPasswordParams.Add("@create_date", user.CreateDate);
                    userPasswordParams.Add("@version_no", user.VersionNo);

                    await postgreDbUtil.InsertAsync(dbConnection, transaction, userPasswordSql, userPasswordParams);
         
                    postgreDbUtil.CommitTransaction(transaction);

                }
                catch (DbException ex)
                {
                    postgreDbUtil.RollBackTransaction(transaction);

                    throw ex;
                }
                catch(Exception ex1)
                {
                    postgreDbUtil.RollBackTransaction(transaction);
                    throw ex1;
                }
                finally
                {
                    postgreDbUtil.CloseConnection();
                }

            }
           
        }

        #endregion


        private Tuser GetUserByUserName(string userName)
        {
            if (userName != null)
                userName = userName.ToLower();
            //take in email field
            string commandText = @"select ua.*, up.password_text,up.password_start_date, up.password_end_date
                                    from public.s_user_account ua inner join s_user_password up on ua.user_account_id = up.user_account_id
                                    where  lower(ua.user_login_id) = @name  -- ua.logon_flag = 'Y' and ua.login_attempts <= 3 and ";
            Dictionary<string, object> parameters = new Dictionary<string, object>() { { "@name", userName } };

            var row = postgreDbUtil.ExecuteQueryGetSingleRow(commandText, parameters);
            return getUserInfo(row);
        }

        private Tuser GetUserByUserId(long id)
        {
            string commandText = @"select ua.*, up.password_text,up.password_start_date, up.password_end_date
                                    from public.s_user_account ua inner join s_user_password up on ua.user_account_id = up.user_account_id
                                    where ua.user_account_id = @id ";
            Dictionary<string, object> parameters = new Dictionary<string, object>() { { "@id", id } };

            var row = postgreDbUtil.ExecuteQueryGetSingleRow(commandText, parameters);
            return getUserInfo(row);
        }

        private Tuser GetUserByEmail(string email)
        {
            string commandText = @"select ua.*, up.password_text,up.password_start_date, up.password_end_date
                                    from public.s_user_account ua inner join s_user_password up on ua.user_account_id = up.user_account_id
                                    where lower(ua.email) = @email";
            Dictionary<string, object> parameters = new Dictionary<string, object>() { { "@email", email } };

            var row = postgreDbUtil.ExecuteQueryGetSingleRow(commandText, parameters);
            return getUserInfo(row);
        }

        private static Tuser getUserInfo(Dictionary<string, string> row)
        {
            if (row == null) return null;
            Tuser user = null;
            user = (Tuser)Activator.CreateInstance(typeof(Tuser));
            user.Id = Convert.ToInt64( row["user_account_id"]);
            user.UserName = row["user_login_id"];
            user.NormalizedUserName = row["user_login_id"];
            // user.LockoutEnd = row["locking_time"] == null ? default : Convert.ToDateTime(row["locking_time"]);
            user.AccessFailedCount = Convert.ToInt32(row["login_attempts"]);
           // user.EmailConfirmed = row["email"].ToString();
           user.LockoutEnabled = row["locked_flag"] == "Y" ? true : false;

           user.PasswordHash = string.IsNullOrEmpty(row["password_text"]) ? null : row["password_text"];
           user.SecurityStamp = string.IsNullOrEmpty(row["security_stamp"]) ? null : row["security_stamp"];
           user.Email = string.IsNullOrEmpty(row["email"]) ? null : row["email"];
            user.NormalizedEmail = string.IsNullOrEmpty(row["email"]) ? null : row["email"];

            user.PhoneNumber = string.IsNullOrEmpty(row["mobile_no"]) ? null : row["mobile_no"];
            
            return user;

        }

    
    }
}
