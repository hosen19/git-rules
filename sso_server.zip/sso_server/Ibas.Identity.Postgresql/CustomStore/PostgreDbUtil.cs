﻿using Ibas.Identity.Postgresql.Core;
using Microsoft.Extensions.Configuration;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ibas.Identity.Postgresql.CustomStore
{
    public class PostgreDbUtil : IPostgreDbUtil, IDisposable
    {
        private static DbConnection _connection;

        private readonly IConfiguration _configurationRoot;
        private static object _lock = new object();

        private readonly DbProviderFactory factory;

        private readonly string connectionString;

        public PostgreDbUtil(IConfiguration configurationRoot)
        {
            _configurationRoot = configurationRoot;
            if (string.IsNullOrEmpty(IdentityDbConfig.StringConnectionName))
                IdentityDbConfig.StringConnectionName = "PgConnectionString";

            connectionString = _configurationRoot.GetConnectionString(IdentityDbConfig.StringConnectionName);

            try
            {
                _connection = new NpgsqlConnection(_configurationRoot.GetConnectionString(IdentityDbConfig.StringConnectionName));
                factory = DbProviderFactories.GetFactory(_connection);
            }
            catch (Exception)
            {
                throw new Exception("Could not connect to the database.");
            }
                
        }

        /// <summary>
        /// Prepare the Connection.
        /// </summary>
        public DbConnection MakeConnection()
        {
            var Connection = factory.CreateConnection();
            Connection.ConnectionString = connectionString;
            return Connection;
            
        }

        /// <summary>
        /// Begin the sql Transaction.
        /// </summary>
        /// <param name="connection">Connection.</param>
        /// <returns>Transaction.</returns>
        public DbTransaction BeginTransaction(DbConnection connection)
        {
            if (connection != null)
                return connection.BeginTransaction(IsolationLevel.ReadCommitted);
            else
                return null;
        }
        /// <summary>
        /// Transaction Commit.
        /// </summary>
        public void CommitTransaction(DbTransaction Transaction)
        {
            if (Transaction != null)
            {
                Transaction.Commit();
            }
        }
        /// <summary>
        /// RollBack the Transaction.
        /// </summary>
        public void RollBackTransaction(DbTransaction Transaction)
        {
            if (Transaction != null)
            {
                Transaction.Rollback();
            }
        }

        // async Task
        public async Task<object> InsertAsync(DbConnection connection, DbTransaction transaction ,string sql, Dictionary<string, object> parameters)
        {
            ArgumentNullException.ThrowIfNull(connection);
            ArgumentNullException.ThrowIfNull(transaction);
            ArgumentNullException.ThrowIfNull(sql);

            var command = factory.CreateCommand();
            command.Connection = connection;
            command.CommandText = sql;
            AddParameters(command, parameters);
            return await command.ExecuteScalarAsync();
        }


        public async Task<int> ExecuteSQLAsync(string commandText, Dictionary<string, object> parameters)
        {
            var result = 0;
            if (string.IsNullOrEmpty(commandText))
            {
                throw new ArgumentException("Command text cannot be null or empty.");
            }

            using (var connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;

                using (var command = factory.CreateCommand())
                {
                    command.Connection = connection;
                    command.CommandText = commandText;
                    AddParameters(command, parameters);

                    await connection.OpenAsync().ConfigureAwait(false); 
                    await command.ExecuteNonQueryAsync();
                }
            }

            Task.CompletedTask.Wait();

            return result;
           
        }

        public object ExecuteQueryGetSingleObject(string commandText, Dictionary<string, object> parameters)
        {
            lock (_lock)
            {
                object result = null;

                if (string.IsNullOrEmpty(commandText))
                {
                    throw new ArgumentException("Command text cannot be null or empty.");
                }

                try
                {
                    OpenConnection();
                    var command = CreateCommand(commandText, parameters);
                    result = command.ExecuteScalar();
                }
                finally
                {
                    CloseConnection();
                }

                return result;
            }
        }

        public Dictionary<string, string> ExecuteQueryGetSingleRow(string commandText,
            Dictionary<string, object> parameters)
        {
            lock (_lock)
            {
                Dictionary<string, string> row = null;
                if (string.IsNullOrEmpty(commandText))
                {
                    throw new ArgumentException("Command text cannot be null or empty.");
                }

                try
                {
                    OpenConnection();
                    var command = CreateCommand(commandText, parameters);
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            row = new Dictionary<string, string>();
                            for (var i = 0; i < reader.FieldCount; i++)
                            {
                                var columnName = reader.GetName(i);
                                var columnValue = reader.IsDBNull(i) ? null : reader.GetValue(i).ToString();
                                row.Add(columnName, columnValue);
                            }
                            break;
                        }
                    }
                }
                finally
                {
                    CloseConnection();
                }

                return row;
            }
        }

        public List<Dictionary<string, string>> ExecuteQuery(string commandText, Dictionary<string, object> parameters)
        {
            lock (_lock)
            {
                List<Dictionary<string, string>> rows = null;
                if (string.IsNullOrEmpty(commandText))
                {
                    throw new ArgumentException("Command text cannot be null or empty.");
                }

                try
                {
                    OpenConnection();
                    var command = CreateCommand(commandText, parameters);
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        rows = new List<Dictionary<string, string>>();
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, string>();
                            for (var i = 0; i < reader.FieldCount; i++)
                            {
                                var columnName = reader.GetName(i);
                                var columnValue = reader.IsDBNull(i) ? null : reader.GetValue(i).ToString();
                                row.Add(columnName, columnValue);
                            }
                            rows.Add(row);
                        }
                    }
                }
                finally
                {
                    CloseConnection();
                }

                return rows;
            }
        }

        private DbCommand CreateCommand(string commandText, Dictionary<string, object> parameters)
        {

            DbCommand command = _connection.CreateCommand();
            command.CommandText = commandText;
            AddParameters(command, parameters);

            return command;

        }

        /// <summary>
        ///     Adds the parameters to a PostgreSQL command.
        /// </summary>
        /// <param name="commandText">The PostgreSQL query to execute.</param>
        /// <param name="parameters">Parameters to pass to the PostgreSQL query.</param>
        private static void AddParameters(DbCommand command, Dictionary<string, object> parameters)
        {
            if (parameters == null)
            {
                return;
            }

            foreach (var param in parameters)
            {
                var parameter = command.CreateParameter();
                parameter.ParameterName = param.Key;
                parameter.Value = param.Value ?? DBNull.Value;

               
                command.Parameters.Add(parameter);
            }
        }

        /// <summary>
        ///     Helper method to return query a string value.
        /// </summary>
        /// <param name="commandText">The PostgreSQL query to execute.</param>
        /// <param name="parameters">Parameters to pass to the PostgreSQL query.</param>
        /// <returns>The string value resulting from the query.</returns>
        private string GetStrValue(string commandText, Dictionary<string, object> parameters)
        {
            var value = ExecuteQueryGetSingleObject(commandText, parameters) as string;
            return value;
        }

        /// <summary>
        ///     Opens a connection if not open.
        /// </summary>
        public void OpenConnection()
        {

            if (_connection == null)
            {
                if (string.IsNullOrEmpty(IdentityDbConfig.StringConnectionName))
                    IdentityDbConfig.StringConnectionName = "PostgreSQLBaseConnection";

                _connection =
                    new Npgsql.NpgsqlConnection(_configurationRoot.GetConnectionString(IdentityDbConfig.StringConnectionName));
            }
            var retries = 3;
            if (_connection.State == ConnectionState.Open)
            {
            }
            else
            {
                while (retries >= 0 && _connection.State != ConnectionState.Open)
                {
                    lock (_lock)
                    {
                        _connection.Close();
                        _connection.Open();
                    }
                    retries--;
                    Thread.Sleep(50);
                }
            }
        }


        /// <summary>
        ///     Closes the connection if it is open.
        /// </summary>
        public void CloseConnection()
        {
            if (_connection.State == ConnectionState.Open)
            {
                _connection.Close();
            }
        }

        public void Dispose()
        {
            //this.Dispose();
        }

    }
}
