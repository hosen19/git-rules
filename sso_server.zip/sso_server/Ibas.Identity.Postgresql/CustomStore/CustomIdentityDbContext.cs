﻿using Ibas.Identity.Postgresql.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.CustomStore
{
    public class CustomIdentityDbContext<Tuser> : ICustomIdentityDbContext<Tuser> where Tuser : class
    {
        private readonly IUserRepository<Tuser> _userRepository;
        public CustomIdentityDbContext(IUserRepository<Tuser> userRepository) {
            this._userRepository = userRepository;
        }

        public IUserRepository<Tuser> UserRepository { get { return _userRepository; } }

       
    }
}
