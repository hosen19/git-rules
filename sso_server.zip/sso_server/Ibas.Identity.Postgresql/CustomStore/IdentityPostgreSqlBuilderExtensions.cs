using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Ibas.Identity.Postgresql.CustomStore;

namespace Microsoft.Extensions.DependencyInjection;

/// <summary>
/// Contains extension methods to <see cref="IdentityBuilder"/> for adding with postgreSql stores.
/// </summary>
public static class IdentityPostgreSqlBuilderExtensions
{
    /// <summary>
    /// Adds an PostgreSql implementation of identity information stores.
    /// </summary>
    /// <param name="builder">The <see cref="IdentityBuilder"/> instance this method extends.</param>
    /// <returns>The <see cref="IdentityBuilder"/> instance this method extends.</returns>

    public static IdentityBuilder AddPostgreSQLStores(this IdentityBuilder builder)
    {
        AddStores(builder.Services, builder.UserType, builder.RoleType);
        return builder;
    }

    private static void AddStores(IServiceCollection services, Type userType, Type? roleType)
    {
        var identityUserType = FindGenericBaseType(userType, typeof(IdentityUser<>));
        if (identityUserType == null)
        {
            throw new InvalidOperationException("NotIdentityUser");
        }

        var keyType = identityUserType.GenericTypeArguments[0];

        Type userStoreType;

        userStoreType = typeof(UserOnlyStore<,>).MakeGenericType(userType,
              keyType
               );
        services.TryAddScoped(typeof(IUserStore<>).MakeGenericType(userType), userStoreType);

    }

    private static Type? FindGenericBaseType(Type currentType, Type genericBaseType)
    {
        Type? type = currentType;
        while (type != null)
        {
            var genericType = type.IsGenericType ? type.GetGenericTypeDefinition() : null;
            if (genericType != null && genericType == genericBaseType)
            {
                return type;
            }
            type = type.BaseType;
        }
        return null;
    }
}
