﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.CustomStore
{
    public class IdpContext : DbContext
    {
        public IdpContext(DbContextOptions<IdpContext> options)
          : base(options) { }
    }
}
