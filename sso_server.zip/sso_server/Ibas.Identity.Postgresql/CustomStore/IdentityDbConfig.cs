﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.CustomStore
{
    public class IdentityDbConfig
    {
        public static string StringConnectionName { get; set; }
    }
}
