﻿using Microsoft.AspNetCore.Identity;

namespace Ibas.Identity.Postgresql.Models
{
    /// <summary>
    /// Table name s_user_account 
    /// </summary>
    public class AppUser : IdentityUser<long>
    {
        // Id -> UserAccountId (PK)
        // UserName -> UserLoginId
        // AccessFailedCount -> login_attempts
        // LockoutEnabled -> locked_flag -> Y or N
        // LockoutEnd -> locking_time -> timestamp
        // SecurityStamp -> security_stamp
        // Email -> email
        // PhoneNumber -> mobile_no 

        /// <summary>
        /// Set Y if User Session is active otherwise N
        /// </summary>
        public string? LogonFlag { get; set; }  // Y or N 

        public string UserAccountNameEn { get;set; }
        public string UserAccountNameBn { get; set; }
        public int ? GenderTypeId { get; set; }
        public DateTime Dob { get; set; }
        public string? NidNo { get; set; }
        public string? SmartNo { get; set;}

        /// <summary>
        /// Password Set by Admin, If user's forgot the credential
        /// </summary>
        public string? IsPasswordSetByAdmin { get; set; } // Y or N

        public int ReferenceStatusId { get; set; }

        public int CreateUserAccountId { get; set; }
        public int UpdateUserAccountId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public int VersionNo { get; set; }

        /// <summary>
        /// Prompt the user to change the login credential
        /// </summary>
        public  int ForcePasswordChange { get; set; }

        /// <summary>
        /// Increment the number , failed count when user's try to change the login credential
        /// </summary>
        public int PasswordChangeAttempts { get; set; }

        /// <summary>
        /// Store Last change password date, This information is relevent with password policy
        /// </summary>
        public DateTime PasswordLastChangeDate { get; set; }

        /// <summary>
        /// Store Last login date for sucessful user's login 
        /// </summary>
        public DateTime LastLoginDate { get; set; }
        public string Remarks { get; set; }


        // User Password Information 
        // PasswordHash -> password_text

        public DateTime PasswordStartDate { get; set; }
        public DateTime PasswordEndDate { get; set; }

    }
}