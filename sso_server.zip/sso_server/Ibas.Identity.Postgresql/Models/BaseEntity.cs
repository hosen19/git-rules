﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibas.Identity.Postgresql.Models
{
    public class BaseEntity
    {
        public int CreateUserAccountId { get; set; }
        public int UpdateUserAccountId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public int VersionNo { get; set; }

    }
}
