﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SSO_Persistence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSO_Persistence
{
    public class SecurityDbContext : IdentityDbContext<AppUser>
    {
        public SecurityDbContext(DbContextOptions<SecurityDbContext> options)
            : base(options) { }
    }
}
