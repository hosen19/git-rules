﻿using System.Security.Cryptography;

namespace sso_server.Services
{
    public class RsaKeyService
    {
        private readonly RSA _privateRsa;
        private readonly RSA _publicRsa;
        public RsaKeyService(string publicKeyPath, string privateKeyPath)
        {
            // Read the public key from the file
            var publicKeyPem = File.ReadAllText(publicKeyPath);
            _publicRsa = RSA.Create();
            _publicRsa.ImportFromPem(publicKeyPem.ToCharArray());

            // Read the private key from the file
            var privateKeyPem = File.ReadAllText(privateKeyPath);
            _privateRsa = RSA.Create();
            _privateRsa.ImportFromPem(privateKeyPem.ToCharArray());
        }
    }
}
