﻿using Ibas.Identity.Postgresql.CustomStore;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using OpenIddict.Abstractions;
using sso_server.Models;
using sso_server.Utility;
//using SSO_Persistence;
using System;
using System.Security.Cryptography;

namespace sso_server.Services
{
    internal static class OpenIdDictRegistration
    {
        internal static IServiceCollection AddOpenIddictService(this IServiceCollection services, IConfiguration configuration)
        {
            var endPoints = configuration.GetSection("Idp:Endpoints").Get<EndPointsModel>();
            var keys = configuration.GetSection("Keys").Get<KeysModel>();
            var rsa = RSA.Create();

            // Code to generate RSA keys
            //var p = Convert.ToBase64String(rsa.ExportRSAPrivateKey()); 
           // var pub = Convert.ToBase64String(rsa.ExportRSAPublicKey());

            rsa.ImportRSAPublicKey(Convert.FromBase64String(keys.PublicKey), out _);
            rsa.ImportRSAPrivateKey(Convert.FromBase64String(keys.PrivateKey), out _);

            // Use the RSA keys for signing and encryption
            var signingKey = new RsaSecurityKey(rsa);

            services
                .AddOpenIddict()

                .AddCore(options =>
                {
                    options
                        .UseEntityFrameworkCore()
                        .UseDbContext<IdpContext>();
                    // Enable Quartz.NET integration.
                    options.UseQuartz();
                   // .SetMinimumAuthorizationLifespan(TimeSpan.FromMinutes(10))
                    //.SetMinimumTokenLifespan(TimeSpan.FromMinutes(10));
                })
                .AddServer(options =>
                {
                    options
                         // .AllowClientCredentialsFlow()
                          .AllowAuthorizationCodeFlow()
                          .RequireProofKeyForCodeExchange()
                          .AllowPasswordFlow()
                          .AllowRefreshTokenFlow();
                    /*
                    options
                        .SetTokenEndpointUris("/sso/connect/token")
                        .SetAuthorizationEndpointUris("/sso/connect/authorize")
                        .SetUserinfoEndpointUris("/sso/connect/userinfo")//;
                        .SetVerificationEndpointUris("/sso/connect/verify")
                        .SetLogoutEndpointUris("/sso/connect/logout")
                        .SetIntrospectionEndpointUris("/sso/connect/introspect");
                    */
                    options
                    .SetTokenEndpointUris(endPoints != null ? endPoints.Token : "/connect/token")
                    .SetAuthorizationEndpointUris(endPoints != null ? endPoints.Authorization : "/connect/authorize")
                    .SetUserinfoEndpointUris(endPoints != null ? endPoints.Userinfo : "/connect/userinfo")
                    .SetVerificationEndpointUris(endPoints != null ? endPoints.Verification : "/connect/verify")
                    .SetLogoutEndpointUris(endPoints != null ? endPoints.Logout  :"/connect/logout")
                    .SetIntrospectionEndpointUris(endPoints != null ? endPoints.Introspection :"/connect/introspect");

                    options
                         .AddEphemeralEncryptionKey()
                         //.AddEphemeralSigningKey()  // This line will enable for default generated RSA keys.
                         .DisableAccessTokenEncryption();

                    options.AddSigningKey(signingKey);  // This line is for generated RSA keys.
                    /*
                    options
                        .AddDevelopmentEncryptionCertificate()
                        .AddDevelopmentSigningCertificate();
                    */
                    // Register scopes (permissions)
                    options.RegisterScopes("api");
                    options.RegisterScopes("offline_access");

                    // Token Life time
                    options.SetAccessTokenLifetime(TimeSpan.FromMinutes(10));
                    options.SetRefreshTokenLifetime(TimeSpan.FromHours(12));

                    // Register the ASP.NET Core host and configure the ASP.NET Core-specific options.
                    options
                        .UseAspNetCore()
                        .EnableAuthorizationEndpointPassthrough()
                        .EnableLogoutEndpointPassthrough()
                        .EnableTokenEndpointPassthrough()
                        .EnableUserinfoEndpointPassthrough()
                        .EnableVerificationEndpointPassthrough()
                        .DisableTransportSecurityRequirement();
                        //.DisableTransportSecurityRequirement();
                        /*
                        .EnableTokenEndpointPassthrough()
                        .EnableAuthorizationEndpointPassthrough()
                        .EnableUserinfoEndpointPassthrough();
                        */
                     
                })
                .AddValidation(options =>
                {
                    options.UseLocalServer();
                    options.UseAspNetCore();
                    //options.EnableAuthorizationEntryValidation();
                });

            //services.AddScoped<IOpenIddictApplicationStore<OpenIdApplication>, OpenIdApplicationStore>();

            return services;
        }
    }
}
