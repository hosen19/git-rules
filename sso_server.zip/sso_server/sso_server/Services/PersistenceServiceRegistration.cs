﻿using Ibas.Identity.Postgresql.Core;
using Ibas.Identity.Postgresql.CustomStore;
using Ibas.Identity.Postgresql.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using sso_server.Models;
//using SSO_Persistence;
//using SSO_Persistence.Model;
using sso_server.Utility;
using static OpenIddict.Abstractions.OpenIddictConstants;

namespace sso_server.Services
{
    internal static class PersistenceServiceRegistration
    {
        internal static void AddPersitenceServices(this IServiceCollection service, IConfiguration configuration)
        {
            #region Configuration for MySQl

            // var serverVersion = new MySqlServerVersion(configuration.GetConnectionString("MySQLVersion"));
            /*
            service.AddDbContext<SecurityDbContext>(options =>
            {
                options.UseMySql(configuration.GetConnectionString("MySQLConnectionString"), serverVersion);
               // options.UseOpenIddict();
            });
            */

            #endregion

            #region Configuration for PostgreSQL
            service.AddDbContext<IdpContext>(options =>
            {
                options.UseNpgsql(configuration.GetConnectionString("PgConnectionString"));
                options.UseOpenIddict();
            });

            #endregion

            // Extended Password Hasher 
            // service.AddScoped<IPasswordHasher<AppUser>, IbasPasswordHasher<AppUser>>();

            // Set the iteration 
            /*
            service.Configure<PasswordHasherOptions>(option =>
            {
                option.IterationCount = 10000;
            });
            */

            /*
             service.AddIdentityCore<AppUser>()
                 .AddEntityFrameworkStores<SecurityDbContext>()
                 //.AddUserStore<UserStorePg>()
                 .AddSignInManager<SignInManager<AppUser>>()
                 .AddUserManager<UserManager<AppUser>>()
                 .AddDefaultTokenProviders();
            */

            service.AddIdentityCore<AppUser>()
               .AddPostgreSQLStores()
               .AddSignInManager<SignInManager<AppUser>>()
               .AddUserManager<UserManager<AppUser>>()
               .AddDefaultTokenProviders();

            #region Configuration for Identity Options
            var passwordPolicy = configuration.GetSection("Idp:PasswordPolicy").Get<PasswordOptions>();

            service.Configure<IdentityOptions>(options =>
            {
                options.ClaimsIdentity.UserNameClaimType = Claims.Name;
                options.ClaimsIdentity.UserIdClaimType = Claims.Subject;
                options.ClaimsIdentity.RoleClaimType = Claims.Role;
                options.ClaimsIdentity.EmailClaimType = Claims.Email;

                options.SignIn.RequireConfirmedAccount = false;

                // Set Password Policy
                options.Password.RequireDigit = passwordPolicy.RequireDigit;
                options.Password.RequireLowercase = passwordPolicy.RequireLowercase;
                options.Password.RequireNonAlphanumeric = passwordPolicy.RequireNonAlphanumeric;
                options.Password.RequireUppercase = passwordPolicy.RequireUppercase;
                options.Password.RequiredLength = passwordPolicy.RequiredLength;
                options.Password.RequiredUniqueChars = passwordPolicy.RequiredUniqueChars;

            });

            #endregion


            service.AddSingleton<IPostgreDbUtil, PostgreDbUtil>();
            service.AddScoped<IUserRepository<AppUser>, UserRepository<AppUser>>();
            service.AddScoped<ICustomIdentityDbContext<AppUser>, CustomIdentityDbContext<AppUser>>();

        }
    }
}
