﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using sso_server.Models;
using Microsoft.AspNetCore.Identity;
//using SSO_Persistence.Model;
using static OpenIddict.Abstractions.OpenIddictConstants;
using OpenIddict.Abstractions;
using System.Security.Principal;
using Ibas.Identity.Postgresql.Models;
using OpenIddict.Server.AspNetCore;

namespace sso_server.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<AppUser> _signInManager;
        private readonly UserManager<AppUser> _userManager;
        private readonly ClaimsIdentity _claimsIdentity;
        public AccountController(SignInManager<AppUser> signInManager, UserManager<AppUser> userManager)
        {
            _signInManager = signInManager ?? throw new ArgumentNullException(nameof(signInManager));
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            ViewData["ReturnUrl"] = model.ReturnUrl;
            
            if (ModelState.IsValid)
            {
                var userInfo = await _userManager.FindByNameAsync(model.Username);
                if(userInfo != null)
                {
                    var result = await _signInManager.CheckPasswordSignInAsync(userInfo, model.Password,false);  //
                   // var result = await _signInManager.PasswordSignInAsync(model.Username, model.Password, false, lockoutOnFailure: false);
                    if (result.Succeeded)
                    {
                        
                        var claims = new List<Claim>
                        {
                         
                            new Claim(ClaimTypes.Name, model.Username),
                       //     new Claim(ClaimTypes.GivenName, userInfo.FirstName),
                            new Claim(ClaimTypes.NameIdentifier, userInfo.Id.ToString()),
                            new Claim(ClaimTypes.Email, userInfo.Email)
                        };

                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                        
                        // Sign in Cookie will be remove after browser close
                        //  await _signInManager.SignInWithClaimsAsync(userInfo,isPersistent:false, claims);
                      //  await HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity));
                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(claimsIdentity));
                        
                        if (Url.IsLocalUrl(model.ReturnUrl))
                        {
                            return Redirect(model.ReturnUrl);
                        }

                        return RedirectToAction(nameof(HomeController.Index), "Home");
                    }
                }
               
            }

            return View(model);
        }


        [HttpGet("~/account/register")]
        [AllowAnonymous]
        public IActionResult Register(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost("~/account/register")]
        [AllowAnonymous]
        // [ValidateAntiForgeryToken]
       // [Authorize]
        public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                var user = new AppUser
                {
                    UserName = model.UserLoginId,
                    Email = model.Email,
                    UserAccountNameBn = model.UserAccountNameBn,
                    UserAccountNameEn = model.UserAccountNameEn,
                    PhoneNumber = model.PhoneNumber,
                    Dob = model.Dob,
                    GenderTypeId = model.GenderTypeId,
                    NidNo = model.NidNo,
                    SmartNo = model.SmartNo,
                    IsPasswordSetByAdmin = model.IsPasswordSetByAdmin,
                    Remarks = model.Remarks,
                    ReferenceStatusId = model.ReferenceStatusId,
                    CreateDate = DateTime.Now,
                    VersionNo = 1,
                    PasswordStartDate = DateTime.Now,
                    PasswordEndDate = DateTime.Now.AddMonths(3)
                };

                try
                {
                    var result = await _userManager.CreateAsync(user, model.Password);
                    if (result.Succeeded)
                    {
                        // return RedirectToLocal(returnUrl);
                        return Json(model);
                    }

                }
                catch (Exception ex)
                {
                    return Json(ex.Message.ToString());
                }
               

               // AddErrors(result);
            }
            return Json( model);

        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();

            return RedirectToAction(nameof(HomeController.Index), "Home");
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(AccountController.Login), "Home");
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

    }
}
