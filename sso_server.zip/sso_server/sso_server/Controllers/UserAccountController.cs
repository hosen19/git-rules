﻿using Ibas.Identity.Postgresql.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OpenIddict.Abstractions;
using OpenIddict.Validation.AspNetCore;
using sso_server.Models;

namespace sso_server.Controllers
{
    [Authorize(AuthenticationSchemes = OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme)]
    public class UserAccountController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly IConfiguration _configuration;
        private readonly PasswordPolicyModel _passwordPolicyModel;
        public UserAccountController(UserManager<AppUser> userManager, IConfiguration configuration)
        {
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(_configuration));
            _passwordPolicyModel = _configuration.GetSection("Idp:PasswordPolicy").Get<PasswordPolicyModel>();
        }

        [HttpPost("~/useraccount/register")]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            ArgumentNullException.ThrowIfNull(_passwordPolicyModel);
            
            if (ModelState.IsValid)
            {
                var user = new AppUser
                {
                    UserName = model.UserLoginId,
                    Email = model.Email,
                    UserAccountNameBn = model.UserAccountNameBn,
                    UserAccountNameEn = model.UserAccountNameEn,
                    PhoneNumber = model.PhoneNumber,
                    Dob = model.Dob,
                    GenderTypeId = model.GenderTypeId,
                    NidNo = model.NidNo,
                    SmartNo = model.SmartNo,
                    IsPasswordSetByAdmin = model.IsPasswordSetByAdmin,
                    Remarks = model.Remarks,
                    ReferenceStatusId = model.ReferenceStatusId,
                    CreateDate = DateTime.Now,
                    VersionNo = 1,
                    PasswordStartDate = DateTime.Now,
                    PasswordEndDate = DateTime.Now.AddMonths(_passwordPolicyModel.PasswordExpireDuration)
                };

                try
                {
                    var result = await _userManager.CreateAsync(user, model.Password);
                    if (result.Succeeded)
                    {
                        return Json(model);
                    }

                    return Json(result.Errors);

                }
                catch (Exception ex)
                {
                    return Json(ex.Message.ToString());
                }

            }
            return ValidationProblem(ModelState);

        }

        [HttpPost("~/useraccount/changepassword")]
        public async Task<IActionResult> PasswordChange(ChangePasswordModel model)
        {
            ArgumentNullException.ThrowIfNull(_passwordPolicyModel);
            var user = await _userManager.FindByNameAsync(model.UserLoginId);
            ArgumentNullException.ThrowIfNull(user);

            if (ModelState.IsValid)
            {
                user.PasswordStartDate = DateTime.Now;
                user.PasswordEndDate = DateTime.Now.AddMonths(_passwordPolicyModel.PasswordExpireDuration);

                try
                {
                    var result = await _userManager.ChangePasswordAsync(user, model.PreviousPassword,model.Password);
                    if (result.Succeeded)
                    {
                        return Json(model);
                    }

                    return Json(result.Errors);

                }
                catch (Exception ex)
                {
                    return Json(ex.Message.ToString());
                }

            }
            return ValidationProblem(ModelState);

        }

    }
}
