﻿using System.ComponentModel.DataAnnotations;

namespace sso_server.Models
{
    public class RegisterViewModel
    {
        [Required]
        [Display(Name = "LoginId")]
        public string UserLoginId { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }


        [Required]
        [Display(Name = "User Account Name (EN)")]
        public string UserAccountNameEn { get; set; }

        [Required]
        [Display(Name = "User Account Name (BN)")]
        public string UserAccountNameBn { get; set; }
        [Required]
        public int? GenderTypeId { get; set; }
        [Required]
        public DateTime Dob { get; set; }
        [Required]
        public string? NidNo { get; set; }
        public string? SmartNo { get; set; }
        [Required]
        public string? IsPasswordSetByAdmin { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        public string Remarks { get; set; }

        [Required]
        public int ReferenceStatusId { get; internal set; }
    }
}
