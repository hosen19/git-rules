﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace sso_server.Models
{
    public class ChangePasswordModel
    {
        [Required]
        [Display(Name = "LoginId")]
        public string UserLoginId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Previous Password")]
        public string PreviousPassword { get; set; }

    }
}
