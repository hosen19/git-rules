﻿namespace sso_server.Models
{
    public class EndPointsModel
    {
        public string Authorization {  get; set; }
        public string Introspection { get; set; }
        public string Logout { get; set; }
        public string Token { get; set; }
        public string Userinfo { get; set; }
        public string Verification { get; set; }
        public string Device {  get; set; }

    }
}
