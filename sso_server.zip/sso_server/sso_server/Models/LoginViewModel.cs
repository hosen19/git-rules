using System.ComponentModel.DataAnnotations;

namespace sso_server.Models
{
    public class LoginViewModel
    {
        [Required]
        public string Username { get; set; }  // user_login_id
        [Required]
        public string Password { get; set; }

        public string ReturnUrl { get; set; }
    }
}