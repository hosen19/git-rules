﻿namespace sso_server.Models
{
    /// <summary>
    /// Represent Password Policy for user account
    /// </summary>
    public class PasswordPolicyModel
    {
        public int PasswordExpireDuration { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating if passwords must contain a digit. Defaults to true.
        /// </summary>
        /// <value>True if passwords must contain a digit.</value>
        public bool RequireDigit { get; set; }

    }
}
