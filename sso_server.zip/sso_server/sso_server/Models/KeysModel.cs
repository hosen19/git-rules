﻿namespace sso_server.Models
{
    public class KeysModel
    {
        public string PrivateKey { get; set; }
        public string PublicKey { get; set; }
    }
}
