
using Ibas.Identity.Postgresql.Core;
using Ibas.Identity.Postgresql.CustomStore;
using Ibas.Identity.Postgresql.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OpenIddict.Abstractions;
using Quartz;
//using SSO_Persistence;
using sso_server;
using sso_server.Services;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        ConfigurationManager configurationManager = builder.Configuration;

        // Add services to the container.
        builder.Services.AddControllersWithViews();

        builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
        {
            builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
        }));

        //// OpenIddict offers native integration with Quartz.NET to perform scheduled tasks
        builder.Services.AddQuartz(options =>
        {
            options.UseMicrosoftDependencyInjectionJobFactory();
            options.UseSimpleTypeLoader();
            options.UseInMemoryStore();
        });
        // Register the Quartz.NET service and configure it to block shutdown until jobs are complete.
        builder.Services.AddQuartzHostedService(options => options.WaitForJobsToComplete = true);

        builder.Services.AddPersitenceServices(configurationManager);
        builder.Services.AddOpenIddictService(configurationManager);


        builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)

        .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
        {
            options.LoginPath = "/account/login";
        });

        builder.Services.AddHostedService<Worker>();


        var app = builder.Build();

        // Configure the HTTP request pipeline.

        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
           app.UseHsts();
        }

        app.UseHttpsRedirection(); // Block for server deployment
        app.UseStaticFiles();

        app.UseRouting();
        app.UseCors("corsapp");

        app.UseAuthentication();

        app.UseAuthorization();

       

        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Home}/{action=Index}/{id?}");

        app.Run();
    }
}