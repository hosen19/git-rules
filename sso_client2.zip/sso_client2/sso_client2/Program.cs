using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);


//JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
//JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap.Clear();

builder.Services.AddHttpContextAccessor();

https://learn.microsoft.com/en-us/aspnet/core/security/cookie-sharing?view=aspnetcore-7.0

builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(@"F:\ibas_keys"))
    .SetApplicationName("ibasIdpApp");

builder.Services.ConfigureApplicationCookie(options => {
    options.Cookie.Name = ".AspNet.ibasIdpCookie";
});


builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;

})
     .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options => {
         options.ExpireTimeSpan = TimeSpan.FromMinutes(2);
         /*
         options.Events.OnValidatePrincipal = context =>
         {
             // This Code Is prevent try from diffrent domain 

             if (context.Properties.Items.TryGetValue("OpenIdConnect.Code.RedirectUri", out string redirectUri))
             {
                 Uri cookieWasSignedForUri = new Uri(redirectUri);
                 if (context.Request.Host.Host != cookieWasSignedForUri.Host)
                 {
                     context.RejectPrincipal();
                 }
             }
             // To Do
             // Reject the ClaimPricipal by default.
                context.RejectPrincipal();

             return Task.CompletedTask;
         };
         */
     })
    //https://stackoverflow.com/questions/44227873/multiple-subdomains-cookie-in-asp-net-core-identity/44310683
    //https://stackoverflow.com/questions/66347314/prevent-asp-net-core-cookie-authentication-from-accepting-cookies-signed-for-dif
    // https://stackoverflow.com/questions/58493233/openidconnect-redirect-on-form-post
    /*
    .AddCookie(options =>
    {
        options.LoginPath = "/callback/login";
        options.LogoutPath = "/logout";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(1);
        options.SlidingExpiration = false;
       // options.Cookie.Name = ".ibasauth";
        //options.AccessDeniedPath = "/logout";
        //options.Cookie.Domain = ".localhost";

        options.Events.OnSigningIn = ctx =>
        {
            Console.WriteLine();
            Console.WriteLine("Claims received by the Cookie handler");
            foreach (var claim in ctx.Principal.Claims)
            {
                Console.WriteLine($"{claim.Type} - {claim.Value}");
                // Check the Claim Here
            }
           
            Console.WriteLine();
            return Task.CompletedTask;
        };

        options.Events.OnValidatePrincipal = context =>
        {
            if (context.Properties.Items.TryGetValue("OpenIdConnect.Code.RedirectUri", out string redirectUri))
            {
                Uri cookieWasSignedForUri = new Uri(redirectUri);
                if (context.Request.Host.Host != cookieWasSignedForUri.Host)
                {
                    context.RejectPrincipal();
                }
            }
         //   context.RejectPrincipal();

            return Task.CompletedTask;
        };
       
    })
    */
    .AddOpenIdConnect(options =>
    {
    options.ClientId = "dev1_client";
    options.ClientSecret = "dev1_secret";

    options.RequireHttpsMetadata = false;
    options.GetClaimsFromUserInfoEndpoint = true;
    options.SaveTokens = false;

    // Use the authorization code flow.
    options.ResponseType = OpenIdConnectResponseType.Code;
    options.AuthenticationMethod = OpenIdConnectRedirectBehavior.RedirectGet;
    options.CallbackPath = "/callback/login1";
    options.Authority = "https://localhost:7058/";
    options.SignedOutCallbackPath = "/signout-callback-oidc";
    options.SignedOutRedirectUri = "https://localhost:44387/logout1";
    options.Scope.Clear();
    options.Scope.Add("openid");
    options.Scope.Add("api1");

    // Disable the built-in JWT claims mapping feature.
    // options.MapInboundClaims = false;

    /*
    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters{
        ValidateAudience = true,
        ValidAudience = "resource_server_api1"
    };
    */
        //Enables or disables the use of the Proof Key for Code Exchange (PKCE) standard
        options.UsePkce = true;
        options.UseTokenLifetime = false;

        options.Events = new OpenIdConnectEvents
        {
            OnTicketReceived = ctx =>
            {
                
                foreach (var claim in ctx.Principal.Claims)
                {
                    Console.WriteLine($"{claim.Type} - {claim.Value}");
                }
                return Task.CompletedTask;
            },
            OnUserInformationReceived = ctx =>
            {
                Console.WriteLine();
                Console.WriteLine("Claims from the ID token");
                foreach (var claim in ctx.Principal.Claims)
                {
                    Console.WriteLine($"{claim.Type} - {claim.Value}");
                }
                Console.WriteLine();
                Console.WriteLine("Claims from the UserInfo endpoint");
                foreach (var property in ctx.User.RootElement.EnumerateObject())
                {
                    Console.WriteLine($"{property.Name} - {property.Value}");
                }
                return Task.CompletedTask;
            },
            OnAuthenticationFailed = (ctx) =>
            {
               //ctx.
                return Task.CompletedTask;
            },
            OnRemoteSignOut = ctx =>
            {
               var cookieCollection = ctx.Request.Cookies;
                return Task.CompletedTask;
            },
            OnSignedOutCallbackRedirect = ctx =>
            {
                ctx.Response.Redirect(ctx.Options.SignedOutRedirectUri);
                ctx.HandleResponse();
                return Task.CompletedTask;
            }
            
    };
    });

//https://nestenius.se/2023/03/28/missing-openid-connect-claims-in-asp-net-core/

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddHttpClient();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
