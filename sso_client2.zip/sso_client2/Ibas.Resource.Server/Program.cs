using IdentityModel.AspNetCore.OAuth2Introspection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using OpenIddict.Validation.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configuration for Openiddict Client

builder.Services.AddOpenIddict()
    .AddValidation(options =>
    {
        options.SetIssuer("https://localhost:7058/");
        options.AddAudiences("resource_server_api");
        options.UseSystemNetHttp();
        options.UseAspNetCore();
    });

builder.Services.AddAuthentication(OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme);
builder.Services.AddAuthentication();


// Now Configure for Auth2.0 Not Working
/*
builder.Services.AddAuthentication(option =>
{
    option.DefaultAuthenticateScheme = OAuth2IntrospectionDefaults.AuthenticationScheme;
})
                    .AddOAuth2Introspection(options =>
                    {
                        options.Authority = "https://localhost:7058/";
                        options.ClientId = "dev_client";
                        options.ClientSecret = "dev_secret";
                      
                    });
builder.Services.AddAuthentication();
*/
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
