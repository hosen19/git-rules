﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OpenIddict.Validation.AspNetCore;

namespace Ibas.Resource.Server.Controllers
{
    [Route("api")]
    public class ResourceController : Controller
    {
         [Authorize(AuthenticationSchemes = OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme)]
        //[Authorize]
        [HttpGet("message")]

        public IActionResult GetMessage()
        {
            return Content($"{User.Identity.Name} has been successfully authenticated.");
        }
    }
}
